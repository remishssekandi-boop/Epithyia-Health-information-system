<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Browse the EPITHYIA GROUP hospital directory for Kampala.">
  <title>Hospital directory — EPITHYIA GROUP</title>
  <link rel="stylesheet" href="/css/style.css">
  <link rel="stylesheet" href="/css/hospitals.css">
  <script src="/js/api.js" defer></script>
  <script src="/js/site.js" defer></script>
  <script src="/js/hospitals.js" defer></script>
</head>
<body>
  <a class="skip-link" href="#main">Skip to content</a>
  <header class="site-header">
    <a class="brand" href="/" aria-label="EPITHYIA GROUP home"><span class="brand-mark" aria-hidden="true">E</span><span>EPITHYIA <strong>GROUP</strong></span></a>
    <nav class="main-nav" aria-label="Main navigation"><a href="/">Home</a><a href="/health-information.php">Health information</a><a href="/about.php">About</a><a href="/contact.php">Contact</a></nav>
    <div class="header-actions"><div class="auth-entry"><a class="button button-quiet" href="/login.php">Log in</a><a class="button button-small" href="/register.php">Join</a></div><div class="auth-session" hidden><span class="welcome-label">Hello, <strong data-user-name></strong></span><button class="button button-quiet" type="button" data-logout>Log out</button></div></div>
  </header>
  <main id="main" class="page-shell">
    <section class="page-intro"><p class="eyebrow">Kampala hospital directory</p><h1>Find the right hospital<br><em>and plan your visit.</em></h1><p>Search published locations, telephone numbers, listed services, opening information, and emergency contacts. Call ahead to confirm that the needed department is available.</p></section>
    <section class="hospital-search" aria-label="Search hospitals">
      <label for="hospital-query">Search by hospital name or location</label>
      <div class="hospital-search-row"><input id="hospital-query" type="search" maxlength="100" placeholder="Search hospitals"><button id="hospital-search-button" class="button" type="button">Search</button></div>
    </section>
    <p id="hospital-count" class="hospital-count" aria-live="polite">Loading hospitals…</p>
    <div id="hospital-results" class="hospital-grid" aria-live="polite"><p class="loading-note">Loading directory…</p></div>
    <p class="content-notice hospital-disclaimer">Information is drawn from hospital websites and Kampala Capital City Authority listings. Hours and service availability can change; call ahead to confirm. This directory is not an emergency response service. Use emergency contacts only for the hospital and unit named.</p>
  </main>
  <footer class="site-footer"><a class="brand brand-footer" href="/">EPITHYIA <strong>GROUP</strong></a><p>Practical hospital and health information for Kampala communities.</p><span>© <span data-current-year></span> EPITHYIA GROUP</span></footer>
</body>
</html>
